A=load('cuarteto.txt'); %Descargamos archivo.

par1=A(:,[1:2]);
par2=A(:,[3:4]);
Par3=A(:,[5:6]);
Par4=A(:,[7:8]);

% Promedio para todas las columnas, separaremos promedios X equivalentes a
% p y promedios Y equivalentes a q, esto nos ayudara al momento de hacer la
% tabla.

p=mean(A); % Con esto obtenemos directamente los valores de cada columna. 
p1=mean(A(:,1)) 
q1=mean(A(:,2))
p2=mean(A(:,3))
q2=mean(A(:,4))
p3=mean(A(:,5))
q3=mean(A(:,6))
p4=mean(A(:,7))
q4=mean(A(:,8))

%Desviacion estandar para todas las columnas, igualmente separaremos en
%Desviacion X equivalente a n y Desviacion Y equivalente a m para ordenar
%la tabla.

n=std(A); % Con esto obtenemos directamente la desviacion para cada columna.
n1=std(A(:,1))
m1=std(A(:,2))
n2=std(A(:,3))
m2=std(A(:,4))
n3=std(A(:,5))
m3=std(A(:,6))
n4=std(A(:,7))
m4=std(A(:,8))

% Covarianza para cada par x_iy_i.

x1y1=cov(A(:,[1:2])); 
a=x1y1(1,2) % Valor que nos importa.
x2y2=cov(A(:,[3:4]));
b=x2y2(1,2) % Valor que nos importa.
x3y3=cov(A(:,[5:6]));
c=x3y3(1,2) % Valor que nos importa.
x4y4=cov(A(:,[7:8]));
d=x4y4(1,2) % Valor que nos importa.

%Teniendo la recta ya podemos obtener el valor de la pendiente y de la
%ordenada.
%Ademas teniendo el coeficiente de correlacion podemos obtener el
%coeficiente de determinacion, que es equivalente al cuadrado del coeficiete de
%correlacion. Notemos que se sigue trabajando en partes.

recta1=polyfit(A(:,1),A(:,2),1) % Para columna 1 y 2.
f=polyval(recta1,A(:,1))
pendiente1=recta1(1,1)
ordenada1=recta1(1,2)
cr1=corrcoef(A(:,[1:2]))
cd1=(cr1(1,2))^2

recta2=polyfit(A(:,3),A(:,4),1) % Para columna 3 y 4.
g=polyval(recta2,A(:,3))
pendiente2=recta2(1,1)
ordenada2=recta2(1,2)
cr2=corrcoef(A(:,[3,4]))
cd2=(cr2(1,2))^2

recta3=polyfit(A(:,5),A(:,6),1) % Para columna 5 y 6.
h=polyval(recta3,A(:,5))
pendiente3=recta3(1,1)
ordenada3=recta3(1,2)
cr3=corrcoef(A(:,[5,6]))
cd3=(cr3(1,2))^2

recta4=polyfit(A(:,7),A(:,8),1) % Para columna 7 y 8.
i=polyval(recta4,A(:,7))
pendiente4=recta4(1,1)
ordenada4=recta4(1,2)
cr4=corrcoef(A(:,[7,8]))
cd4=(cr4(1,2))^2


% Ahora generamos tabla.

Columnas={'Par1';'Par2';'Par3';'Par4'};
PromedioX=[p1;p2;p3;p4];
PromedioY=[q1;q2;q3;q4];
DesviacionX=[n1;n2;n3;n4];
DesviacionY=[m1;m2;m3;m4]
Covarianza=[a;b;c;d];
Pendiente=[pendiente1;pendiente2;pendiente3;pendiente4];
Ordenada=[ordenada1;ordenada2;ordenada3;ordenada4];
CoefD=[cd1;cd2;cd3;cd4];


T=table(Columnas,PromedioX,PromedioY,DesviacionX,DesviacionY,Covarianza,Pendiente,Ordenada,CoefD)

% Generamos las 4 graficas generaadas por cada parte.

subplot(2,2,1)
plot(A(:,1),A(:,2),'o')
hold on
plot(A(:,1),f,'linewidth',2)
xlabel('eje x','FontSize',16)
ylabel('eje y','FontSize',16)
title('Par 1','FontSize',20)
legend('datos','recta ajustada')


subplot(2,2,2)
plot(A(:,3),A(:,4),'o')
hold on
plot(A(:,3),g,'linewidth',2)
xlabel('eje x','FontSize',16)
ylabel('eje y','FontSize',16)
title('Par 2','FontSize',20)
legend('datos','recta ajustada')

subplot(2,2,3)
plot(A(:,5),A(:,6),'o')
hold on
plot(A(:,5),h,'linewidth',2)
xlabel('eje x','FontSize',16)
ylabel('eje y','FontSize',16)
title('Par 3','FontSize',20)
legend('datos','recta ajustada')

subplot(2,2,4)
plot(A(:,7),A(:,8),'o')
hold on
plot(A(:,7),i,'linewidth',2)
xlabel('eje x','FontSize',16)
ylabel('eje y','FontSize',16)
title('Par 4','FontSize',20)
legend('datos','recta ajustada')

set(gcf,'Color','w')







